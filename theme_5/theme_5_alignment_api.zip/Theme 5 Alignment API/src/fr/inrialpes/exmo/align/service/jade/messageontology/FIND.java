package fr.inrialpes.exmo.align.service.jade.messageontology;

import jade.content.Predicate;

/**
* Protege name: FIND
* @author ontology bean generator
* @version 2007/03/19, 17:12:29
*/
public class FIND extends Action implements Predicate {

    private static final long serialVersionUID = 330;
}
