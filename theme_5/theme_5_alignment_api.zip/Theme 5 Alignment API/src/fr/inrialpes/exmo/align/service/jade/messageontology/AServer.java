package fr.inrialpes.exmo.align.service.jade.messageontology;

import jade.core.AID;

/**
* Protege name: AServer
* @author ontology bean generator
* @version 2007/03/19, 17:12:29
*/
public class AServer extends AID { 

    private static final long serialVersionUID = 330;
}
