package fr.inrialpes.exmo.align.service.jade.messageontology;

import jade.content.Predicate;

/**
* Protege name: RETRIEVE
* @author ontology bean generator
* @version 2007/03/19, 17:12:29
*/
public class RETRIEVE extends Action implements Predicate {

    private static final long serialVersionUID = 330;
}
